package app;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) {
        try {
            // Leer productos y vendedores desde los CSV
            Map<String, Integer> productos = leerProductos("input/products.csv");
            Map<Long, String> vendedores = leerVendedores("input/salesmen.csv");

            // Procesar archivos de ventas
            procesarVentas("input/vendors", productos, vendedores);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static Map<String, Integer> leerProductos(String ruta) throws IOException {
        Map<String, Integer> productos = new HashMap<String, Integer>();
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        String linea = br.readLine(); // Saltar encabezado
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(";");
            String id = partes[0];
            int precio = Integer.parseInt(partes[2]);
            productos.put(id, precio);
        }
        br.close();
        return productos;
    }

    private static Map<Long, String> leerVendedores(String ruta) throws IOException {
        Map<Long, String> vendedores = new HashMap<Long, String>();
        BufferedReader br = new BufferedReader(new FileReader(ruta));
        String linea = br.readLine(); // Saltar encabezado
        while ((linea = br.readLine()) != null) {
            String[] partes = linea.split(";");
            long cedula = Long.parseLong(partes[1]);
            String nombre = partes[2] + " " + partes[3];
            vendedores.put(cedula, nombre);
        }
        br.close();
        return vendedores;
    }

    private static void procesarVentas(String carpeta, Map<String, Integer> productos, Map<Long, String> vendedores) throws IOException {
        File dir = new File(carpeta);

        // Usamos FilenameFilter en lugar de lambdas (para Java 7)
        File[] archivos = dir.listFiles(new FilenameFilter() {
            @Override
            public boolean accept(File dir, String name) {
                return name.endsWith(".txt");
            }
        });

        if (archivos == null) {
            System.err.println("⚠ No se encontraron archivos en la carpeta: " + carpeta);
            return;
        }

        for (File archivo : archivos) {
            BufferedReader br = new BufferedReader(new FileReader(archivo));
            String primeraLinea = br.readLine(); // Ejemplo: podría tener info del vendedor
            System.out.println("Procesando archivo: " + archivo.getName() + " -> " + primeraLinea);
            br.close();
        }
    }
}

