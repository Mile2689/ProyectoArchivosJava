package app;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

/**
 * Clase encargada de generar archivos de prueba:
 * - Vendedores (salesmen.csv)
 * - Productos (products.csv)
 * - Ventas individuales en la carpeta vendors/
 */
public class GenerateInfoFiles {

    public static void main(String[] args) {
        try {
            // Crear carpetas necesarias
        	File inputDir = new File("input");
        	if (!inputDir.exists()) {
        	    inputDir.mkdirs(); // crea la carpeta "input"
        	}

            File vendorsDir = new File("input/vendors");

            if (!vendorsDir.exists()) {
                if (vendorsDir.mkdirs()) {
                    System.out.println("✅ Carpeta 'input/vendors' creada correctamente.");
                } else {
                    System.err.println("⚠️ No se pudo crear la carpeta 'input/vendors'.");
                }
            }

            // Generar archivos
            createSalesManInfoFile(5);
            createProductsFile(5);

            for (int i = 1; i <= 5; i++) {
                createSalesMenFile(5, "Vendedor" + i, 1000 + i);
            }

            System.out.println("✅ Archivos generados correctamente en /input.");
        } catch (Exception e) {
            System.err.println("❌ Error al generar archivos: " + e.getMessage());
        }
    }

    public static void createSalesMenFile(int randomSalesCount, String name, long id) throws IOException {
        Random rand = new Random();
        File file = new File("input/vendors/" + name + "_" + id + ".txt");

        try (FileWriter writer = new FileWriter(file)) {
            writer.write("CC;" + id + "\n");
            for (int i = 1; i <= randomSalesCount; i++) {
                int cantidad = rand.nextInt(10) + 1;
                writer.write("P00" + i + ";" + cantidad + ";\n");
            }
        }
    }

    public static void createProductsFile(int productsCount) throws IOException {
        File file = new File("input/products.csv");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("ID;Nombre;Precio\n");
            for (int i = 1; i <= productsCount; i++) {
                writer.write("P00" + i + ";Producto" + i + ";" + (1000 * i) + "\n");
            }
        }
    }

    public static void createSalesManInfoFile(int salesmanCount) throws IOException {
        File file = new File("input/salesmen.csv");
        try (FileWriter writer = new FileWriter(file)) {
            writer.write("TipoDocumento;NumeroDocumento;Nombres;Apellidos\n");
            for (int i = 1; i <= salesmanCount; i++) {
                writer.write("CC;" + (1000 + i) + ";Nombre" + i + ";Apellido" + i + "\n");
            }
        }
    }
}


