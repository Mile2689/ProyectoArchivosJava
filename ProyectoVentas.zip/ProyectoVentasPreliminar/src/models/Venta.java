package models;

public class Venta {
    private Producto producto;
    private int cantidad;

    public Venta(Producto producto, int cantidad) {
        this.producto = producto;
        this.cantidad = cantidad;
    }

    public double getValorVenta() {
        return producto.getPrecio() * cantidad;
    }
}
