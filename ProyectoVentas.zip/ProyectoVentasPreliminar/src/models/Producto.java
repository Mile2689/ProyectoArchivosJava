package models;

public class Producto {
    @SuppressWarnings("unused")
	private String id;
    private String nombre;
    private double precio;
    private int cantidadVendida;

    public Producto(String id, String nombre, double precio) {
        this.id = id;
        this.nombre = nombre;
        this.precio = precio;
        this.cantidadVendida = 0;
    }

    public void agregarVenta(int cantidad) {
        this.cantidadVendida += cantidad;
    }

    public int getCantidadVendida() {
        return cantidadVendida;
    }

    public double getPrecio() {
        return precio;
    }

    public String getNombre() {
        return nombre;
    }
}
