package models;

public class Vendedor {
    @SuppressWarnings("unused")
	private String tipoDocumento;
    private String numeroDocumento;
    private String nombres;
    private String apellidos;
    private double totalVentas;

    public Vendedor(String tipoDocumento, String numeroDocumento, String nombres, String apellidos) {
        this.tipoDocumento = tipoDocumento;
        this.numeroDocumento = numeroDocumento;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.totalVentas = 0;
    }

    public void agregarVenta(double valor) {
        this.totalVentas += valor;
    }

    public double getTotalVentas() {
        return totalVentas;
    }

    public String getNombreCompleto() {
        return nombres + " " + apellidos;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }
}

